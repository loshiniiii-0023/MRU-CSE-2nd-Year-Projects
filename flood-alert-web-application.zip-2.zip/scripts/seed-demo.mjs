import { cert, getApps, initializeApp } from 'firebase-admin/app'
import { FieldValue, getFirestore } from 'firebase-admin/firestore'

const projectId = process.env.GCLOUD_PROJECT || process.env.FIREBASE_PROJECT_ID || 'flood-alert-mru'
if (projectId !== 'flood-alert-mru') throw new Error(`Refusing to seed unexpected Firebase project: ${projectId}`)

const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON
const app = getApps().length
  ? getApps()[0]
  : initializeApp(serviceAccountJson ? { credential: cert(JSON.parse(serviceAccountJson)), projectId } : { projectId })
const db = getFirestore(app)
const now = () => FieldValue.serverTimestamp()
const demo = (label, description) => ({ isDemonstration: true, demoLabel: label, description, source: 'FloodWatch demonstration seed' })
const point = (latitude, longitude) => ({ latitude, longitude })

const records = {
  FloodAlerts: Object.fromEntries([
    ['01', ['Hussain Sagar advisory', 'Advisory', 'Hussain Sagar', 17.4239, 78.4738]],
    ['02', ['Musi river watch', 'Watch', 'Nampally river edge', 17.385, 78.4867]],
    ['03', ['Begumpet low-lying area', 'Advisory', 'Begumpet', 17.4448, 78.4661]],
    ['04', ['Secunderabad drainage watch', 'Watch', 'Secunderabad', 17.4399, 78.4983]],
    ['05', ['Charminar district advisory', 'Advisory', 'Charminar', 17.3616, 78.4747]],
    ['06', ['Kukatpally demonstration alert', 'Advisory', 'Kukatpally', 17.4849, 78.4138]],
    ['07', ['LB Nagar demonstration watch', 'Watch', 'LB Nagar', 17.3457, 78.5522]],
    ['08', ['Mehdipatnam demonstration advisory', 'Advisory', 'Mehdipatnam', 17.3949, 78.4326]],
  ].map(([id, [title, severity, area, latitude, longitude]]) => [`demo-alert-hyderabad-${id}`, {
    title: `Demonstration ${title}`, severity, area: `${area} (fictional)`, ...demo('DEMO — NOT A REAL EMERGENCY', 'Fictional demonstration content for the FloodWatch college project. This is not a real emergency.'), ...point(latitude, longitude), updatedAt: now(),
  }])),
  FloodReports: Object.fromEntries([
    ['01', ['Begumpet demonstration point', 17.4448, 78.4661]], ['02', ['Tank Bund demonstration point', 17.4239, 78.4738]],
    ['03', ['Nampally demonstration point', 17.385, 78.4867]], ['04', ['Charminar demonstration point', 17.3616, 78.4747]],
    ['05', ['Kukatpally demonstration point', 17.4849, 78.4138]], ['06', ['LB Nagar demonstration point', 17.3457, 78.5522]],
    ['07', ['Mehdipatnam demonstration point', 17.3949, 78.4326]], ['08', ['Secunderabad demonstration point', 17.4399, 78.4983]],
  ].map(([id, [location, latitude, longitude]]) => [`demo-report-hyderabad-${id}`, {
    userId: 'demo-seed', location, waterLevel: 'medium', needsHelp: false, peopleCount: 0, requestedResources: [], status: 'Pending', ...demo('DEMO — NOT A REAL REPORT', 'Fictional map marker used for demonstration only.'), ...point(latitude, longitude), createdAt: now(),
  }])),
  Shelters: Object.fromEntries([
    ['01', ['Demonstration Community Hall', 'Tank Bund', 120, 180, 17.4239, 78.4738]], ['02', ['Demonstration Civic Centre', 'Nampally', 75, 120, 17.385, 78.4867]],
    ['03', ['Demonstration School Hall', 'Begumpet', 48, 90, 17.4448, 78.4661]], ['04', ['Demonstration Sports Complex', 'Kukatpally', 200, 260, 17.4849, 78.4138]],
    ['05', ['Demonstration Relief Hall', 'Charminar', 62, 100, 17.3616, 78.4747]], ['06', ['Demonstration Community School', 'LB Nagar', 90, 140, 17.3457, 78.5522]],
    ['07', ['Demonstration Ward Hall', 'Mehdipatnam', 35, 70, 17.3949, 78.4326]], ['08', ['Demonstration Public Hall', 'Secunderabad', 110, 160, 17.4399, 78.4983]],
  ].map(([id, [name, address, available, capacity, latitude, longitude]]) => [`demo-shelter-hyderabad-${id}`, {
    name, address: `${address}, Hyderabad (fictional)`, available, capacity, status: 'Open', ...demo('DEMO — NOT A VERIFIED SHELTER', 'Fictional shelter record for demonstration only. Do not use for real emergency planning.'), ...point(latitude, longitude), updatedAt: now(),
  }])),
  Hospitals: Object.fromEntries([
    ['01', ['Demonstration General Hospital', 'Begumpet', 17.4448, 78.4661]], ['02', ['Demonstration City Hospital', 'Nampally', 17.385, 78.4867]],
    ['03', ['Demonstration Medical Centre', 'Secunderabad', 17.4399, 78.4983]], ['04', ['Demonstration Care Hospital', 'Mehdipatnam', 17.3949, 78.4326]],
    ['05', ['Demonstration Emergency Clinic', 'LB Nagar', 17.3457, 78.5522]],
  ].map(([id, [name, area, latitude, longitude]]) => [`demo-hospital-hyderabad-${id}`, {
    name, address: `${area}, Hyderabad (fictional)`, status: 'Open', emergencyServices: true, ...demo('DEMO — NOT A VERIFIED HOSPITAL', 'Fictional hospital record for demonstration only. Do not use for real medical care.'), ...point(latitude, longitude), updatedAt: now(),
  }])),
  RescueTeams: Object.fromEntries([
    ['01', ['Demonstration Rescue Team North', 'Secunderabad', 17.4399, 78.4983]], ['02', ['Demonstration Rescue Team Central', 'Nampally', 17.385, 78.4867]],
    ['03', ['Demonstration Rescue Team East', 'LB Nagar', 17.3457, 78.5522]], ['04', ['Demonstration Rescue Team West', 'Kukatpally', 17.4849, 78.4138]],
    ['05', ['Demonstration Rescue Team South', 'Mehdipatnam', 17.3949, 78.4326]],
  ].map(([id, [name, area, latitude, longitude]]) => [`demo-rescue-team-hyderabad-${id}`, {
    name, area: `${area} (fictional)`, status: 'Available', teamSize: 6, ...demo('DEMO — NOT A VERIFIED RESCUE TEAM', 'Fictional rescue team record for demonstration only. Do not use for real emergency dispatch.'), ...point(latitude, longitude), updatedAt: now(),
  }])),
  Resources: Object.fromEntries([
    ['01', ['Demonstration relief supplies', 'Secunderabad', 50, 17.4399, 78.4983]], ['02', ['Demonstration water kits', 'Begumpet', 80, 17.4448, 78.4661]],
    ['03', ['Demonstration first-aid kits', 'Nampally', 35, 17.385, 78.4867]], ['04', ['Demonstration blankets', 'Charminar', 120, 17.3616, 78.4747]],
    ['05', ['Demonstration food parcels', 'Kukatpally', 90, 17.4849, 78.4138]], ['06', ['Demonstration hygiene kits', 'LB Nagar', 60, 17.3457, 78.5522]],
    ['07', ['Demonstration sandbags', 'Hussain Sagar', 200, 17.4239, 78.4738]], ['08', ['Demonstration torches', 'Mehdipatnam', 45, 17.3949, 78.4326]],
  ].map(([id, [name, area, quantity, latitude, longitude]]) => [`demo-resource-hyderabad-${id}`, {
    name, title: 'Fictional resource marker', address: `${area}, Hyderabad (fictional)`, quantity, unit: 'kits', ...demo('DEMO — NOT A VERIFIED RESOURCE', 'Fictional resource record for demonstration only. Do not use for real emergency distribution.'), ...point(latitude, longitude), updatedAt: now(),
  }])),
}

for (const [collectionName, documents] of Object.entries(records)) {
  for (const [id, data] of Object.entries(documents)) {
    await db.collection(collectionName).doc(id).set(data, { merge: true })
    console.log(`Seeded ${collectionName}/${id}`)
  }
}
console.log('Demo seed complete. Records are fictional, labelled, deterministic, and merge-written.')
