'use client'

import { useEffect, useState } from 'react'
import { CircleMarker, MapContainer, Popup, TileLayer, useMap, useMapEvents } from 'react-leaflet'
import { LocateFixed } from 'lucide-react'
import type { LatLngBoundsExpression } from 'leaflet'

type MapRecord = {
  id?: string
  kind: 'alert' | 'report' | 'shelter' | 'resource' | 'hospital' | 'rescue'
  label: string
  latitude: number
  longitude: number
  isDemonstration?: boolean
  demoLabel?: string
  status?: string
  description?: string
  address?: string
  available?: number | string
}

const colors = {
  alert: '#b51f30',
  report: '#d9283c',
  shelter: '#245483',
  resource: '#2563eb',
  hospital: '#f97316',
  rescue: '#7c3aed',
}

function FitAllControl({ records }: { records: MapRecord[] }) {
  const map = useMap()
  const fitAll = () => {
    if (!records.length) return
    map.fitBounds(records.map((record) => [record.latitude, record.longitude] as [number, number]), { padding: [42, 42], maxZoom: 14 })
  }
  return <button type="button" onClick={fitAll} aria-label="Fit all locations" title="Fit all locations" className="absolute right-3 top-14 z-[1000] rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-[#071d3b] shadow-md hover:bg-slate-50">Fit all</button>
}

function UserLocationControl() {
  const map = useMap()
  const locate = () => {
    if (!navigator.geolocation) return
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => map.flyTo([coords.latitude, coords.longitude], Math.max(map.getZoom(), 14)),
      () => undefined,
      { enableHighAccuracy: true, timeout: 8000 },
    )
  }
  return <button type="button" onClick={locate} aria-label="Use my location" title="Use my location" className="absolute right-3 top-3 z-[1000] grid size-10 place-items-center rounded-lg border border-slate-200 bg-white text-[#071d3b] shadow-md hover:bg-slate-50"><LocateFixed className="size-5" /></button>
}

function ZoomState({ onZoom }: { onZoom: (zoom: number) => void }) {
  useMapEvents({ zoomend: (event) => onZoom(event.target.getZoom()) })
  return null
}

function groupRecords(records: MapRecord[], zoom: number) {
  if (zoom >= 13) return records.map((record) => ({ latitude: record.latitude, longitude: record.longitude, records: [record] }))
  const cellSize = zoom <= 8 ? 0.18 : zoom <= 10 ? 0.08 : 0.025
  const groups = new Map<string, { latitude: number; longitude: number; records: MapRecord[] }>()
  records.forEach((record) => {
    const key = `${Math.floor(record.latitude / cellSize)}:${Math.floor(record.longitude / cellSize)}`
    const group = groups.get(key) ?? { latitude: 0, longitude: 0, records: [] }
    group.records.push(record)
    group.latitude += record.latitude
    group.longitude += record.longitude
    groups.set(key, group)
  })
  return [...groups.values()].map((group) => ({ latitude: group.latitude / group.records.length, longitude: group.longitude / group.records.length, records: group.records }))
}

function FitBounds({ records }: { records: MapRecord[] }) {
  const map = useMap()
  useEffect(() => {
    if (!records.length) return
    const bounds: LatLngBoundsExpression = records.map((record) => [record.latitude, record.longitude])
    map.fitBounds(bounds, { padding: [42, 42], maxZoom: 14 })
  }, [map, records])
  return null
}

export default function LiveMap({ records }: { records: MapRecord[] }) {
  const center: [number, number] = records.length
    ? [records.reduce((sum, record) => sum + record.latitude, 0) / records.length, records.reduce((sum, record) => sum + record.longitude, 0) / records.length]
    : [17.385, 78.4867]
  const [zoom, setZoom] = useState(12)
  const groups = groupRecords(records, zoom)

  return (
    <MapContainer center={center} zoom={records.length ? 12 : 11} scrollWheelZoom className="h-[480px] w-full">
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <UserLocationControl />
      {records.length > 0 && <FitAllControl records={records} />}
      <ZoomState onZoom={setZoom} />
      {records.length > 0 && <FitBounds records={records} />}
      {groups.map((group) => {
        const record = group.records[0]
        const clustered = group.records.length > 1
        const color = clustered ? '#071d3b' : colors[record.kind]
        return <CircleMarker key={clustered ? `cluster-${group.latitude}-${group.longitude}` : `${record.kind}-${record.id}`} center={[group.latitude, group.longitude]} radius={clustered ? Math.min(22, 10 + group.records.length) : record.kind === 'alert' ? 10 : 8} pathOptions={{ color, fillColor: color, fillOpacity: 0.9, weight: 3 }}>
          <Popup>
            {clustered ? <><strong>{group.records.length} nearby locations</strong><div className="mt-2 space-y-1">{group.records.map((item) => <div key={`${item.kind}-${item.id}`}><span style={{ color: colors[item.kind] }}>●</span> {item.isDemonstration ? 'DEMO — ' : ''}{item.label}</div>)}</div><div className="mt-2 text-xs text-slate-500">Zoom in to separate markers.</div></> : <><strong>{record.isDemonstration ? 'DEMO — ' : ''}{record.label}</strong>{record.demoLabel && <div>{record.demoLabel}</div>}{record.status && <div>Status: {record.status}</div>}{record.address && <div>{record.address}</div>}{record.available !== undefined && <div>Available: {record.available}</div>}{record.description && <div>{record.description}</div>}<div className="mt-1 text-xs text-slate-500">{record.latitude.toFixed(5)}, {record.longitude.toFixed(5)}</div></>}
          </Popup>
        </CircleMarker>
      })}
    </MapContainer>
  )
}
